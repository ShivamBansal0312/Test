import React, { Component } from "react";
import  "react-bootstrap";
import './Front.css';
import { Button, Form, FormGroup, Label, Input } from "reactstrap";

class Front extends React.Component {
  constructor(props) {
    super(props);
  }

  
  handleSubmit(event) {
    
    event.preventDefault();
  }

  render() {
    return (
      <div>
        <nav class="navbar navbar-expand-lg navbar-light bg-primary">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
        <div class="navbar-nav ml-auto">
            <span class="navbar-text">
        <b>Filter By:-</b>
    </span>
        <a class="nav-link" href="#"><b>Jobs, </b></a>
        <a class="nav-link" href="#"><b>Companies |</b></a>
        <a class="nav-link" href="#"><b>Logout</b></a>
    </div>
  </div>
</nav>
<div class="modal-body row">
  <div class="col-md-8" >
    <h2>LOGO</h2>
    <input type="text" id="inline" class="form-control" placeholder='Skills'></input>
    <input type="text" id="inline" class="form-control" placeholder='Location'></input>
    <button>Find Jobs</button>
  </div>
  <div class="col-md-4" id="mid">
  <h3>Login</h3>
    <input type="text" class="form-control" placeholder='Email id'></input>
    <input type="text" class="form-control" placeholder='Psssword'></input>
    <button id="button">Submit</button><br></br>
    <a href='#'>New User? Register as Fresher/ Experience </a>
  </div>
</div> 
<div id='block'>
    <h3>Hot Jobs</h3>
    
</div>
      </div>
    );
  }
}

export default Front; 