var JobAll = React.createClass({   
  
  getInitialState: function () {  
    return { jobid: '' ,jobtitle: '',jobdate:'',jobrole:'',jobrespon:'',jobcomp:'',jobexp:'',jobsalary:'',
    jobposition:'',joblocation:'',jobskill:'',jobdegree:'',jobinfo:'',jobemploy:'',jobindust:'',jobsearch:'',jobdescp:'',id:'',Buttontxt:'Save', data1: []};  
  },  
   handleChange: function(e) {  
        this.setState({[e.target.name]: e.target.value});  
    },  
  
  componentDidMount() {  
   
    $.ajax({  
       url: "api/getdata",  
       type: "GET",  
       dataType: 'json',  
       ContentType: 'application/json',  
       success: function(data) {           
         this.setState({data1: data});   
           
       }.bind(this),  
       error: function(jqXHR) {  
         console.log(jqXHR);  
             
       }.bind(this)  
    });  
  },  
    
  

  
  render: function() {
    return (
      <div>
        <nav class="navbar navbar-expand-lg navbar-light bg-primary">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
        <div class="navbar-nav ml-auto">
            <span class="navbar-text">
        <b>Filter By:-</b>
    </span>
        <a class="nav-link" href="#"><b>Jobs, </b></a>
        <a class="nav-link" href="#"><b>Companies |</b></a>
        <a class="nav-link" href="#"><b>Logout</b></a>
    </div>
  </div>
</nav>
<div class="row">
  <div class="column left" >
    <h2>LOGO</h2>
    <input type="text" id="inline" class="form-control" placeholder='Skills'></input>
    <input type="text" id="inline" class="form-control" placeholder='Location'></input>
    <button>Find Jobs</button>
  </div>
  <div class="column right" id="mid">
  <h3>Login</h3>
    <input type="text" class="form-control" placeholder='Email id'></input>
    <input type="text" class="form-control" placeholder='Psssword'></input>
    <button id="button">Submit</button><br></br>
    <a href='#'>New User? Register as Fresher/ Experience </a>
  </div>
</div> 
<div id='block'>
    <h3>Hot Jobs</h3>
    <div className="col-sm-12 col-md-12 "  style={{paddingTop:'30px',paddingBottom:'30px'}}>  
     
   <table className="table-bordered"><tbody>  
     <tr>
       <th style={{padding:'20px'}}><b>S.No</b></th>
       <th style={{padding:'20px'}}><b>JOB ID</b></th>
       <th style={{padding:'20px'}}><b>JOB TITLE</b></th>
       <th style={{padding:'20px'}}><b>JOB POSTED DATE</b></th>
       <th style={{padding:'20px'}}><b>ROLE</b></th>
       <th style={{padding:'20px'}}><b>RESPONSIBILITY</b></th>
       
      </tr>  
      {this.state.data1.map((item, index) => (  
          <tr key={index}>  
             <td style={{padding:'10px'}}>{index+1}</td>   
            <td style={{padding:'10px'}}>{item.jobid}</td>                        
            <td style={{padding:'10px'}}>{item.jobtitle}</td>  
            <td style={{padding:'10px'}}>{item.jobdate}</td>  
            <td style={{padding:'10px'}}>{item.jobrole}</td>
            <td style={{padding:'10px'}}>{item.jobrespon}</td>  
            
            </tr>  
      ))}  
      </tbody>
      </table>
      </div>
    </div>
</div>
      
    );
    
  }  
});  
  
ReactDOM.render(<JobAll  />, document.getElementById('root'))